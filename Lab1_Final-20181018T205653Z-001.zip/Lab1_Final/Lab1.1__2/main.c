
//*****************************************************************************

//****************************************************************************
//
//! \addtogroup blinky
//! @{
//
//****************************************************************************

// Standard includes
#include <stdio.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "interrupt.h"
#include "hw_apps_rcm.h"
#include "prcm.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "gpio.h"
#include "utils.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Common interface includes
#include "gpio_if.h"
#include "pinmux.h"
#include "uart.h"
#include "uart_if.h"

//*****************************************************************************
//                          MACROS
//*****************************************************************************
#define APPLICATION_VERSION  "1.1.1"
#define APP_NAME             "UART Echo"
#define CONSOLE              UARTA0_BASE
#define UartGetChar()        MAP_UARTCharGet(CONSOLE)
#define UartPutChar(c)       MAP_UARTCharPut(CONSOLE,c)
#define MAX_STRING_LENGTH    80


//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************


#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif

//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES                           
//*****************************************************************************
void LEDBlinkyRoutine();
static void BoardInit(void);
void uart();

//*****************************************************************************
//                      LOCAL FUNCTION DEFINITIONS                         
//*****************************************************************************

//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
    //
    // Set vector table base
    //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}

static void
DisplayBanner(char * AppName)
{

    Report("\n\n\n\r");
    Report("\t\t *************************************************\n\r");
    Report("\t\t        CC3200 %s Application       \n\r", AppName);
    Report("\t\t *************************************************\n\r");
    Report("\n\n\n\r");
}
//****************************************************************************
//
//! Main function
//!
//! \param none
//! 
//! This function  
//!    1. Invokes the LEDBlinkyTask
//!
//! \return None.
//
//****************************************************************************
void uart(){
    char cString[MAX_STRING_LENGTH+1];
    char cCharacter;
    int iStringLength = 0;
    double stepperMotorRev = 0.0;

    BoardInit();
    PinMuxConfig();
    InitTerm();
    ClearTerm();
    DisplayBanner(APP_NAME);
    Message("\t\t****************************************************\n\r");
    Message("\t\t\t        CC3200 Stepper Motor        \n\r");
    Message("\t\t Enter the desired number of revolutions [1-10] and press enter  \n\r");
    Message("\t\t ****************************************************\n\r");
    Message("\n\n\n\r");


    while(1)
    {

        if(UARTCharsAvail(UARTA0_BASE))
        // Get input from the terminal
        cCharacter = UartGetChar();
        //g_iCounter++;
        if (cCharacter == '\r' || cCharacter == '\n')
        {
            cString[iStringLength] = '\0';
            //bubbles = atof(cString);
            Report("\n\rThe value you entered was %s\n\r", cString);
            stepperMotorRev = atof(cString);
            printf("The value of the motor is: %f\n\r", stepperMotorRev);
            iStringLength = 0;
            //GPIO_Turn_On(stepperMotorRev);
        } else
        {

            UartPutChar(cCharacter);
            cString[iStringLength] = cCharacter;
            iStringLength++;
        }
    }
}
int main()
{
    //GPIOPinWrite(
    BoardInit();
    PinMuxConfig();
    InitTerm();
    ClearTerm();
    DisplayBanner(APP_NAME);
    Message("\t\t****************************************************\n\r");
    Message("\t\t\t        CC3200 Stepper Motor        \n\r");
    Message("\t\t Enter the desired number of revolutions [1-10] and press enter  \n\r");
    Message("\t\t ****************************************************\n\r");
    Message("\n\n\n\r");

    GPIO_IF_GPIO_Configure();
    GPIO_Turn_On();


    return 0;

    /*Pin 61 goes to IN1 on ULN2003A
     * Pin 15 goes to IN1 on ULN2003A
     * Pin 60 goes to IN1 on ULN2003A
     * Pin 62 goes to IN1 on ULN2003A
     * GND goes to GND on ULN2003A
     * Yellow on motor goes to OUT1 on ULN2003A
     * Orange on motor goes to OUT2 on ULN2003A
     * Brown on motor goes to OUT3 on ULN2003A
     * Black on motor goes to OUT4 on ULN2003A
     * 5V on board goes to COM on ULN2003A
     * Green and Red on Motor goes to 5V on board
     * Adjust the delay to make the motor go faster.
     */
}
